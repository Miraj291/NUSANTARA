<div align=center>
 
# 🚀 Spike DDoS 🚀

<p>
 <img src="https://img.shields.io/github/stars/hoaan1995/ZxCDDoS?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/hoaan1995/ZxCDDoS?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/hoaan1995/ZxCDDoS?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

<p align="center">  <a href="https://t.me/mrd4nd2"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>
 
## Language</br>
<img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/>
 </div>
 
 ## Logs</br>
 - DSTAT L7!
 - DONT RESELL THIS TOOLS!
   
# Tree
* [𝕀𝕟𝕗𝕠](#Info)
* [𝕊𝕖𝕥𝕦𝕡](#Setup)
* [ℂ𝕣𝕖𝕕𝕚𝕥𝕤](#Credits)
* [ℙ𝕠𝕨𝕖𝕣](#Power)
* [ℝ𝕦𝕝𝕖𝕤](#TOS)
* [ℂ𝕠𝕟𝕥𝕒𝕔𝕥](#Contact)

# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Premium
- [x] Simple
- [x] Methods for L7

# Setup
```sh
How to use: 
- Using vps with high speed will be stronger

npm i fs
npm i url
npm i net
npm i cluster
npm i events
git clone https://github.com/dandiers/Spike.git
cd Spike
node spike.js
```

# Credits
```sh
dandier (Owner Of This Tools.-.)
```

# Power
<img src="https://progqr.com/Foto.jpg"></img>

# Rules:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```

# CONTACT:
```sh
Telegram: @mrd4nd2
Discord: dandier#1121
```

